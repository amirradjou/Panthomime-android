package com.example.pantomim;


import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import com.readystatesoftware.sqliteasset.SQLiteAssetHelper;

public class DataBaseAccess extends SQLiteAssetHelper  {

    private static String DATABASE_NAME= "Category.db";
    private  static int DATABASE_Version = 1;
    SQLiteDatabase db;
    public DataBaseAccess(Context context) {
        super(context,DATABASE_NAME,null,DATABASE_Version);
        db=getReadableDatabase();
    }
    public  SQLiteDatabase getDb () {
        return  db;
    }

}
