package com.example.pantomim;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class EmtiazClass extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.emtiazat);

        Button next_round_btn = findViewById(R.id.next_round_btn);

        TextView score_gp1 = findViewById(R.id.emtiaz_gp1_id);
        TextView score_gp2 = findViewById(R.id.em2);


        score_gp1.setText(String.valueOf(ScoresListClass.score_gp1));
        score_gp2.setText(String.valueOf(ScoresListClass.score_gp2));

        next_round_btn.setOnClickListener(v -> {
            Intent go_to_soal = new Intent(this , Group_2nafare_Activity.class);
            startActivity(go_to_soal);
        });

        if (ScoresListClass.flag_of_turn==12)
            finish();
    }
}
