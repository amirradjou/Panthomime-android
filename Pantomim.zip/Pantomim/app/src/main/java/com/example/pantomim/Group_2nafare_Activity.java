package com.example.pantomim;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;


public class Group_2nafare_Activity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.group_2nafare_layout);
        Button zarbolmasal = findViewById(R.id.id_zarbolmasl);
        Button ashia = findViewById(R.id.id_ashia);
        Button shoghl = findViewById(R.id.id_shoghl);
        Button heyvanat = findViewById(R.id.id_heyvanat);
        Button varzesh = findViewById(R.id.id_varzesh);
        Button mashahir = findViewById(R.id.id_mashahir);
        Button amaken = findViewById(R.id.id_amaken);





        zarbolmasal.setOnClickListener(v -> {
            Intent intent2 = new Intent(this,Soal_Class.class);
            intent2.putExtra("Category","ضرب المثل");
            startActivity(intent2);

        });

        shoghl.setOnClickListener(v -> {
            Intent intent2 = new Intent(this,Soal_Class.class);
            intent2.putExtra("Category","شغل");
            startActivity(intent2);

        });

        varzesh.setOnClickListener(v -> {
            Intent intent2 = new Intent(this,Soal_Class.class);
            intent2.putExtra("Category","ورزش");
            startActivity(intent2);

        });

        heyvanat.setOnClickListener(v -> {
            Intent intent2 = new Intent(this,Soal_Class.class);
            intent2.putExtra("Category","حیوانات");
            startActivity(intent2);

        });

        ashia.setOnClickListener(v -> {
            Intent intent2 = new Intent(this,Soal_Class.class);
            intent2.putExtra("Category","اشیا");
            startActivity(intent2);

        });

        mashahir.setOnClickListener(v -> {
            Intent intent2 = new Intent(this,Soal_Class.class);
            intent2.putExtra("Category","مشاهیر");
            startActivity(intent2);

        });

        amaken.setOnClickListener(v -> {
            Intent intent2 = new Intent(this,Soal_Class.class);
            intent2.putExtra("Category","اماکن");
            startActivity(intent2);

        });

    }
}
