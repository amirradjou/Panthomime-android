package com.example.pantomim;

public class ScoresListClass {
    static int score_gp1=0;
    static int score_gp2=0;
    static int flag_of_turn=0;
}
