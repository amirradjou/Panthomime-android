package com.example.pantomim;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class Soal_Class extends AppCompatActivity {
    String emtiaz;

    protected void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);



        setContentView(R.layout.soal_layout);
        String mozoo= getIntent().getStringExtra("Category");

        Intent intent_go_to_emtiaz = new Intent(this , EmtiazClass.class);

        DataBaseAccess dbAccess = new DataBaseAccess(this);
        Cursor c= dbAccess.getDb().rawQuery("SELECT* FROM Category" ,null);
        c.moveToFirst();

        TextView textView_kalame = findViewById(R.id.text_kalame_id);


        Button button_3emtiazi = findViewById(R.id.btn_3emtiazi_id);
        Button button_6emtiazi = findViewById(R.id.btn_6emtiazi_id);
        Button button_9emtiazi = findViewById(R.id.btn_9emtiazi_id);
        Button dorost_goft_btn = findViewById(R.id.dorost_goft_id);


        TextView textView = findViewById(R.id.textView_id);
        Button start_timer = findViewById(R.id.start_timer_btn_id);

        CountDownTimer countDownTimer = new CountDownTimer(10 * 1000, 1000) {

            public void onTick(long millisUntilFinished) {
                textView.setText("Seconds remaining: " + millisUntilFinished / 1000);
            }

            public void onFinish() {

                startActivity(intent_go_to_emtiaz);



            }
        };


        button_3emtiazi.setOnClickListener(v -> {
            emtiaz = "3";

            ScoresListClass.flag_of_turn++;
            if (ScoresListClass.flag_of_turn%2 == 1)
                ScoresListClass.score_gp1+=3;
            else
                ScoresListClass.score_gp2+=3;


            while(!c.isAfterLast()){
                if(c.getString(0).equals(mozoo) && c.getString(1).equals(emtiaz)&&c.getString(2).equals("0")){
                    textView_kalame.setText(c.getString(3));
                    break;
                }
                c.moveToNext();
            }
        });

        button_6emtiazi.setOnClickListener(v -> {
            emtiaz = "6";

            ScoresListClass.flag_of_turn++;
            if (ScoresListClass.flag_of_turn%2 == 1)
                ScoresListClass.score_gp1+=6;
            else
                ScoresListClass.score_gp2+=6;

            while(!c.isAfterLast()){
                if(c.getString(0).equals(mozoo) && c.getString(1).equals(emtiaz)&&c.getString(2).equals("0")){
                    textView_kalame.setText(c.getString(3));
                    break;
                }
                c.moveToNext();
            }
        });

        button_9emtiazi.setOnClickListener(v -> {
            emtiaz="9";

            ScoresListClass.flag_of_turn++;
            if (ScoresListClass.flag_of_turn%2 == 1)
                ScoresListClass.score_gp1+=9;
            else
                ScoresListClass.score_gp2+=9;


            while(!c.isAfterLast()){
                if(c.getString(0).equals(mozoo) && c.getString(1).equals(emtiaz)&&c.getString(2).equals("0")){
                    textView_kalame.setText(c.getString(3));
                    break;
                }
                c.moveToNext();
            }
        });

        start_timer.setOnClickListener(v -> {
            countDownTimer.start();
        });

        dorost_goft_btn.setOnClickListener(v -> {

            startActivity(intent_go_to_emtiaz);
            countDownTimer.cancel();
        });

    }
}
