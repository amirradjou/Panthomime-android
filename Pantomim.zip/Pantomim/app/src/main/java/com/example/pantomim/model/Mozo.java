package com.example.pantomim.model;

public class Mozo {
    private  String mozo;

    public Mozo(String mozo) {
        this.mozo = mozo;
    }

    public String getMozo() {
        return mozo;
    }

    public void setMozo(String mozo) {
        this.mozo = mozo;
    }

    @Override
    public String toString() {
        return "Mozo{" +
                "mozo='" + mozo + '\'' +
                '}';
    }

}
